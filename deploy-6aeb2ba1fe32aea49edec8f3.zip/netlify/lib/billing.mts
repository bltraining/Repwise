import Stripe from 'stripe'

// Projet Supabase de l'appli (valeurs publiques, déjà présentes côté navigateur).
const SUPABASE_URL = process.env.SUPABASE_URL || 'https://dpbfkzmoizjdevrwuukb.supabase.co'
const SUPABASE_PUBLISHABLE_KEY = process.env.SUPABASE_PUBLISHABLE_KEY || 'sb_publishable_TeIWWTwf4yC9JEXhP-wzXg_tj5a7Mdo'

export class HttpError extends Error {
  constructor(public status: number, message: string) {
    super(message)
  }
}

export function json(body: unknown, status = 200) {
  return Response.json(body, { status, headers: { 'Cache-Control': 'no-store' } })
}

export function handleError(err: unknown) {
  if (err instanceof HttpError) return json({ error: err.message }, err.status)
  console.error(err)
  return json({ error: 'Erreur inattendue' }, 500)
}

export function getStripe() {
  const key = process.env.STRIPE_SECRET_KEY
  if (!key) throw new HttpError(503, 'Paiement non configuré')
  if (!/^(sk|rk)_(live|test)_/.test(key.trim())) {
    console.error('STRIPE_SECRET_KEY invalide : elle doit commencer par sk_live_, sk_test_ ou rk_')
    throw new HttpError(503, 'Paiement mal configuré (clé Stripe invalide)')
  }
  return new Stripe(key.trim())
}

function serviceKey() {
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY
  if (!key) throw new HttpError(503, 'Paiement non configuré')
  const k = key.trim()
  if (!k.startsWith('eyJ') && !k.startsWith('sb_secret_')) {
    console.error('SUPABASE_SERVICE_ROLE_KEY invalide : elle doit commencer par sb_secret_ ou eyJ')
    throw new HttpError(503, 'Serveur mal configuré (clé Supabase invalide)')
  }
  return k
}

export function adminHeaders(): Record<string, string> {
  const key = serviceKey()
  const h: Record<string, string> = { apikey: key, 'Content-Type': 'application/json' }
  // Les anciennes clés « service_role » sont des JWT ; les nouvelles « sb_secret_ » passent uniquement par apikey.
  if (key.startsWith('eyJ')) h.Authorization = `Bearer ${key}`
  return h
}

export type AuthUser = { id: string; email?: string }

/** Vérifie le jeton de session Supabase envoyé par l'appli. */
export async function requireUser(req: Request): Promise<AuthUser> {
  const auth = req.headers.get('authorization') || ''
  const token = auth.replace(/^Bearer\s+/i, '').trim()
  if (!token) throw new HttpError(401, 'Non connecté')
  const res = await fetch(`${SUPABASE_URL}/auth/v1/user`, {
    headers: { apikey: SUPABASE_PUBLISHABLE_KEY, Authorization: `Bearer ${token}` },
  })
  if (!res.ok) throw new HttpError(401, 'Session invalide')
  const user = (await res.json()) as AuthUser
  if (!user?.id) throw new HttpError(401, 'Session invalide')
  return user
}

export type Profil = {
  id: string
  nom_complet: string | null
  stripe_customer_id: string | null
  stripe_subscription_id: string | null
  premium_jusqu_au: string | null
  resilie: boolean | null
  acces_offert: boolean | null
  role?: string | null
}

export async function getProfil(uid: string): Promise<Profil | null> {
  const url = `${SUPABASE_URL}/rest/v1/profils?id=eq.${encodeURIComponent(uid)}&select=id,nom_complet,stripe_customer_id,stripe_subscription_id,premium_jusqu_au,resilie,acces_offert,role`
  const res = await fetch(url, { headers: adminHeaders() })
  if (!res.ok) throw new Error(`Lecture du profil impossible (${res.status}) ${await res.text()}`)
  const rows = (await res.json()) as Profil[]
  return rows[0] || null
}

export async function updateProfil(uid: string, patch: Partial<Profil>) {
  const res = await fetch(`${SUPABASE_URL}/rest/v1/profils?id=eq.${encodeURIComponent(uid)}`, {
    method: 'PATCH',
    headers: { ...adminHeaders(), Prefer: 'return=minimal' },
    body: JSON.stringify(patch),
  })
  if (!res.ok) throw new Error(`Mise à jour du profil impossible (${res.status}) ${await res.text()}`)
}

/** Retrouve (ou crée) le client Stripe lié au compte. */
export async function ensureCustomer(stripe: Stripe, user: AuthUser, profil: Profil | null) {
  if (profil?.stripe_customer_id) {
    try {
      const c = await stripe.customers.retrieve(profil.stripe_customer_id)
      if (!('deleted' in c && c.deleted)) return c.id
    } catch (err) {
      // Client introuvable (par exemple créé avec d'autres clés) : on en recrée un.
      if (!(err instanceof Stripe.errors.StripeInvalidRequestError)) throw err
    }
  }
  const customer = await stripe.customers.create({
    email: user.email || undefined,
    name: profil?.nom_complet || undefined,
    metadata: { supabase_uid: user.id },
  })
  await updateProfil(user.id, { stripe_customer_id: customer.id })
  return customer.id
}

function periodEnd(sub: Stripe.Subscription): number | null {
  const fromItems = sub.items?.data?.map((i) => i.current_period_end).filter(Boolean) as number[]
  if (fromItems?.length) return Math.max(...fromItems)
  const legacy = (sub as unknown as { current_period_end?: number }).current_period_end
  return legacy || null
}

const LIVE_STATUSES = new Set(['active', 'trialing', 'past_due'])

/**
 * Lit l'état réel de l'abonnement dans Stripe et le recopie dans le profil Supabase
 * (premium_jusqu_au, resilie, stripe_subscription_id), utilisé par a_acces_premium.
 */
export async function syncCustomer(stripe: Stripe, uid: string, customerId: string) {
  const subs = await stripe.subscriptions.list({ customer: customerId, status: 'all', limit: 20 })
  const live = subs.data
    .filter((s) => LIVE_STATUSES.has(s.status))
    .sort((a, b) => (periodEnd(b) || 0) - (periodEnd(a) || 0))[0]

  if (live) {
    const end = periodEnd(live)
    const patch: Partial<Profil> = {
      stripe_customer_id: customerId,
      stripe_subscription_id: live.id,
      resilie: !!(live.cancel_at_period_end || live.cancel_at),
    }
    if (end) patch.premium_jusqu_au = new Date(end * 1000).toISOString()
    await updateProfil(uid, patch)
    return { active: true, ends: patch.premium_jusqu_au || null, resilie: patch.resilie, subscriptionId: live.id, status: live.status }
  }

  // Plus d'abonnement en cours : l'accès s'arrête à la fin de la dernière période payée.
  const last = subs.data.sort((a, b) => (periodEnd(b) || 0) - (periodEnd(a) || 0))[0]
  if (last && last.status !== 'incomplete' && last.status !== 'incomplete_expired') {
    const stop = last.ended_at || periodEnd(last)
    await updateProfil(uid, {
      stripe_customer_id: customerId,
      stripe_subscription_id: last.id,
      resilie: true,
      ...(stop ? { premium_jusqu_au: new Date(stop * 1000).toISOString() } : {}),
    })
  }
  return { active: false, ends: null, resilie: true, subscriptionId: null, status: last?.status || null }
}

export async function uidForCustomer(stripe: Stripe, customerId: string): Promise<string | null> {
  const c = await stripe.customers.retrieve(customerId)
  if ('deleted' in c && c.deleted) return null
  return (c as Stripe.Customer).metadata?.supabase_uid || null
}

export const SUPABASE = { url: SUPABASE_URL, publishableKey: SUPABASE_PUBLISHABLE_KEY }

/** Vérifie le mot de passe du compte (confirmation avant une action sensible). */
export async function checkPassword(email: string, password: string) {
  const res = await fetch(`${SUPABASE_URL}/auth/v1/token?grant_type=password`, {
    method: 'POST',
    headers: { apikey: SUPABASE_PUBLISHABLE_KEY, 'Content-Type': 'application/json' },
    body: JSON.stringify({ email, password }),
  })
  return res.ok
}

/**
 * Supprime le compte via la fonction SQL de l'appli (supprimer_mon_compte, appelée avec la session
 * de l'utilisateur), ou à défaut directement dans l'authentification Supabase.
 */
export async function deleteAccount(uid: string, token: string) {
  const rpc = await fetch(`${SUPABASE_URL}/rest/v1/rpc/supprimer_mon_compte`, {
    method: 'POST',
    headers: { apikey: SUPABASE_PUBLISHABLE_KEY, Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
    body: '{}',
  })
  if (rpc.ok) return
  const txt = await rpc.text()
  if (rpc.status !== 404) {
    if (/coach/i.test(txt)) throw new HttpError(409, 'Ce compte est coach : réassigne d’abord ses clients.')
    throw new Error(`supprimer_mon_compte a échoué (${rpc.status}) ${txt}`)
  }
  await deleteAuthUser(uid)
}

async function deleteAuthUser(uid: string) {
  const res = await fetch(`${SUPABASE_URL}/auth/v1/admin/users/${encodeURIComponent(uid)}`, {
    method: 'DELETE',
    headers: adminHeaders(),
  })
  if (!res.ok) throw new Error(`Suppression du compte impossible (${res.status}) ${await res.text()}`)
}
