import type { Config } from '@netlify/functions'
import { getProfil, handleError, json, requireUser, updateProfil } from '../lib/billing.mts'

// Permet à un compte coach d'activer ou de retirer son propre accès Premium offert (pour les tests).
export default async (req: Request) => {
  try {
    const user = await requireUser(req)
    const body = (await req.json().catch(() => ({}))) as { on?: unknown }
    if (typeof body.on !== 'boolean') return json({ error: 'Requête invalide' }, 400)
    const profil = await getProfil(user.id)
    if (!profil) return json({ error: 'Profil introuvable' }, 404)
    if (profil.role !== 'coach') return json({ error: 'Réservé aux comptes coach' }, 403)
    await updateProfil(user.id, { acces_offert: body.on })
    return json({ acces_offert: body.on })
  } catch (err) {
    return handleError(err)
  }
}

export const config: Config = { path: '/api/coach-access', method: 'POST' }
